﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace WcfService.TestConsole
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Uploading file...");

            var uploadService = new UploadService.UploadServiceClient();
            var success = await uploadService.UploadAsync(new UploadService.UploadRequest
            {
                Content = File.ReadAllBytes("dummy.pdf"),
                Attachment = new UploadService.AttachmentRequest
                {
                    TXLife = new UploadService.TXLife
                    {
                        TXLifeRequest = new UploadService.TXLifeRequest { 
                            OLifE = new UploadService.OLifE
                            {
                                Holding = new UploadService.Holding
                                {
                                    Policy = new UploadService.Policy
                                    {
                                        CarrierPartyID = "test"
                                    }
                                }
                            }
                        }
                    }
                }
            });

            Console.WriteLine(success);
            Console.ReadKey();

        }
    }
}
