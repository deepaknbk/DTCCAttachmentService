﻿using MTOM.Service.DTO;
using System;
using System.IO;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace MTOM.Service.Interfaces
{
    [ServiceContract]
    public interface IUploadService
    {
        [OperationContract]
        bool Upload(UploadRequest request);
    }
}
