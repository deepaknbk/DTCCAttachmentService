﻿namespace MTOM.Service.DTO
{
    public class TransferEncodingTypeTC
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}