﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MTOM.Service.DTO
{
    public class Policy
    {
        public int CusipNum { get; set; }
        public string CarrierPartyID { get; set; }
        public int Text { get; set; }
    }
}