﻿using System;

namespace MTOM.Service.DTO
{
    public class TXLifeRequest
    {
        public string TransRefGUID { get; set; }
        public TransType TransType { get; set; }
        public TransSubType TransSubType { get; set; }
        public DateTime TransExeDate { get; set; }
        public DateTime TransExeTime { get; set; }
        public TestIndicator TestIndicator { get; set; }
        public PrimaryObjectType PrimaryObjectType { get; set; }
        public OLifE OLifE { get; set; }
        public string PrimaryObjectID { get; set; }
        public string Text { get; set; }
    }
}