﻿namespace MTOM.Service.DTO
{
    public class FormInstance
    {
        public string FormName { get; set; }
        public object ProviderFormNumber { get; set; }
        public string DocumentControlNumber { get; set; }
        public DocumentControlType DocumentControlType { get; set; }
        public OriginatingTransType OriginatingTransType { get; set; }
        public Attachment Attachment { get; set; }
        public string ProviderPartyID { get; set; }
        public string ReceiverPartyID { get; set; }
        public string Id { get; set; }
        public string Text { get; set; }
    }
}