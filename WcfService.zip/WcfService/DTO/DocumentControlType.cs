﻿namespace MTOM.Service.DTO
{
    public class DocumentControlType
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}