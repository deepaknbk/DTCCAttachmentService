﻿namespace MTOM.Service.DTO
{
    public class AttachmentHashType
    {
        public int Tc { get; set; }
        public int Text { get; set; }
    }
}