﻿using System.Collections.Generic;

namespace MTOM.Service.DTO
{
    public class OLifE
    {
        public Holding Holding { get; set; }
        public List<Party> Party { get; set; }
        public FormInstance FormInstance { get; set; }
        public List<Relation> Relation { get; set; }
    }
}