﻿namespace MTOM.Service.DTO
{
    public class AttachmentData64
    {
        public Include Include { get; set; }
    }
}