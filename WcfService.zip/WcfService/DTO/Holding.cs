﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MTOM.Service.DTO
{
    public class Holding
    {
        public Policy Policy { get; set; }
        public string Id { get; set; }
        public int Text { get; set; }
    }
}