﻿namespace MTOM.Service.DTO
{
    public class AttachmentType
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}