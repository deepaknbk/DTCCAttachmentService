﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MTOM.Service.DTO
{
    public class PartyTypeCode
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}