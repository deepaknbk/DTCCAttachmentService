﻿namespace MTOM.Service.DTO
{
    public class RelationRoleCode
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}