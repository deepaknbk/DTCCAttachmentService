﻿using System;
using System.IO;

namespace MTOM.Service.DTO
{
    public class Attachment
    {
        public DateTime DateCreated { get; set; }
        public AttachmentBasicType AttachmentBasicType { get; set; }
        public AttachmentData64 AttachmentData64 { get; set; }
        public AttachmentType AttachmentType { get; set; }
        public MimeTypeTC MimeTypeTC { get; set; }
        public TransferEncodingTypeTC TransferEncodingTypeTC { get; set; }
        public AttachmentLocation AttachmentLocation { get; set; }
        public string AttachmentHashValue { get; set; }
        public AttachmentHashType AttachmentHashType { get; set; }
        public string Id { get; set; }
        public string Text { get; set; }
    }
}