﻿namespace MTOM.Service.DTO
{
    public class Include
    {
        public string Href { get; set; }
        public string Xop { get; set; }
    }
}