﻿namespace MTOM.Service.DTO
{
    public class AttachmentLocation
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}