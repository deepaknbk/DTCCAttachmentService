﻿namespace MTOM.Service.DTO
{
    public class OriginatingObjectType
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}