﻿using System.Linq;
using System.Web;

namespace MTOM.Service.DTO
{
    public class AttachmentRequest
    {
        public TXLife TXLife { get; set; }
        public string Dtcc { get; set; }
        public string Text { get; set; }
    }
}