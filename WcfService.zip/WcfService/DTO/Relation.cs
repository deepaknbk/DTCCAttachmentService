﻿namespace MTOM.Service.DTO
{
    public class Relation
    {
        public OriginatingObjectType OriginatingObjectType { get; set; }
        public RelatedObjectType RelatedObjectType { get; set; }
        public RelationRoleCode RelationRoleCode { get; set; }
        public string OriginatingObjectID { get; set; }
        public string RelatedObjectID { get; set; }
        public string Id { get; set; }
        public string Text { get; set; }
    }
}