﻿namespace MTOM.Service.DTO
{
    public class TXLife
    {
        public TXLifeRequest TXLifeRequest { get; set; }
        public string Xmlns { get; set; }
        public string Text { get; set; }
    }
}