﻿namespace MTOM.Service.DTO
{
    public class AttachmentBasicType
    {
        public int Tc { get; set; }
        public string Text { get; set; }
    }
}