﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.Web;

namespace MTOM.Service.DTO
{
    public class UploadRequest
    {
        [MessageHeader(MustUnderstand = true)]

        public AttachmentRequest Attachment;
        [MessageBodyMember(Order = 1)]

        public byte[] Content;
    }
}