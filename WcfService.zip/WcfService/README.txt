﻿I have the WCF service running inside local IIS, you can configure it to run however you choose.
The endpoint is http://localhost/WcfService/UploadService.svc
Use the WcfService.TestConsole to test the service. It has a dummy PDF used for testing the upload.

