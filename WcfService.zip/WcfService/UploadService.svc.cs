﻿using MTOM.Service.DTO;
using MTOM.Service.Interfaces;
using System;
using System.IO;
using System.IO.Pipes;
using System.ServiceModel.Web;

namespace MTOM.Service
{
    public class UploadService : IUploadService
    {
        public bool Upload(UploadRequest request)
        {
            try
            {
                /*
                 * process your upload here
                 * request.Content - your file upload bytes
                 * request.Attachment - your Attachment Metadata which I mimicked as much as I could based on your attached xml
                 */
            }
            catch
            {
                return false;
            }
            return true;
        }
    }
}
